﻿using DLLSalario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TesteChart2
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            // fillChart();
            //fillChart2();
            fillChart3();
            

        }
        private void fillChart3()
        {
            Salario sal = new Salario();

            chart1.DataSource = sal.fillChart3();
            //set the member of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].XValueMember = "Name";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].YValueMembers = "Salary";
            chart1.Titles.Add("Salary Chart");
        }

        private void fillChart()
        {
            //AddXY value in chart1 in series named as Salary  
            chart1.Series["Salary"].Points.AddXY("Ajay", "10000");
            chart1.Series["Salary"].Points.AddXY("Ramesh", "8000");
            chart1.Series["Salary"].Points.AddXY("Ankit", "7000");
            chart1.Series["Salary"].Points.AddXY("Gurmeet", "10000");
            chart1.Series["Salary"].Points.AddXY("Suresh", "8500");
            //chart title  
            chart1.Titles.Add("Salary Chart");
        }

        private void fillChart2()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Sample;Integrated Security=true;");
            DataSet ds = new DataSet();
            con.Open();
            SqlDataAdapter adapt = new SqlDataAdapter("Select Name,Salary from tbl_EmpSalary", con);
            adapt.Fill(ds);
            chart1.DataSource = ds;
            //set the member of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].XValueMember = "Name";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].YValueMembers = "Salary";
            chart1.Titles.Add("Salary Chart");
            con.Close();
        }



    }
}
