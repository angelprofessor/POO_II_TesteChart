﻿using DLLSalario;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace W
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //fillChart2();
            fillChart3();
        }

        private void fillChart2()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Sample;Integrated Security=true;");
            DataSet ds = new DataSet();
            con.Open();
            SqlDataAdapter adapt = new SqlDataAdapter("Select Name,Salary from tbl_EmpSalary", con);
            adapt.Fill(ds);
            chart1.DataSource = ds;
            //set the member of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].XValueMember = "Name";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].YValueMembers = "Salary";
            chart1.Titles.Add("Salary Chart");
            con.Close();
        }

        private void fillChart3()
        {
            Salario sal = new Salario();

            chart1.DataSource = sal.fillChart3();
            //set the member of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].XValueMember = "Name";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
            chart1.Series["Salary"].YValueMembers = "Salary";
            chart1.Titles.Add("Salary Chart");
        }
    }
}