﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
//using System.Windows.Forms.DataVisualization.Charting;

namespace TesteChart
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        void BarExample()
        {
            chartControl.Series.Clear();
            string[] seriesArray = { "Gato", "Cão", "Pássaro", "Macaco" };
            int[] pointsArray = { 2, 1, 7, 5 };

            chartControl.Palette = ChartColorPalette.EarthTones;

            chartControl.Titles.Add("Animais");

            for (int i = 0; i < seriesArray.Length; i++)
            {
                Series series = chartControl.Series.Add(seriesArray[i]);
                series.Points.Add(pointsArray[i]);
            }
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
           BarExample();
        }

    }
}
