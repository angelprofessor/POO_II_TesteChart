﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLLSalario
{
    public class Salario
    {
        public DataSet fillChart3()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Sample;Integrated Security=true;");
            DataSet ds = new DataSet();
            con.Open();
            SqlDataAdapter adapt = new SqlDataAdapter("Select Name,Salary from tbl_EmpSalary", con);
            adapt.Fill(ds);
           // chart1.DataSource = ds;
            //set the member of the chart data source used to data bind to the X-values of the series  
           // chart1.Series["Salary"].XValueMember = "Name";
            //set the member columns of the chart data source used to data bind to the X-values of the series  
           // chart1.Series["Salary"].YValueMembers = "Salary";
           // chart1.Titles.Add("Salary Chart");
            con.Close();

            return ds;
        }
    }
}
